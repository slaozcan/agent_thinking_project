import pandas as pd

df = pd.read_csv("multi_agent_20_v2_results.csv")

total = len(df)

correct = (
    df["expected_esi"] ==
    df["predicted_esi"]
).sum()

accuracy = correct / total

print("=" * 60)
print("MULTI AGENT V2 RESULTS")
print("=" * 60)

print(f"Total Cases : {total}")
print(f"Correct     : {correct}")
print(f"Incorrect   : {total-correct}")
print(f"Accuracy    : {accuracy:.4f}")