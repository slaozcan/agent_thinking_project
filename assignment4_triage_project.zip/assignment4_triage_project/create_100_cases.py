import pandas as pd
from huggingface_hub import hf_hub_download

print("=" * 60)
print("CREATING 100 CASE DATASET")
print("=" * 60)

# ============================================================
# DOWNLOAD DATASET
# ============================================================

file_path = hf_hub_download(
    repo_id="olaflaitinen/fedmml-ed-triage",
    repo_type="dataset",
    filename="fedmml_ed_triage_dataset.csv"
)

df = pd.read_csv(file_path)

print("\nDataset loaded!")
print(f"Total rows: {len(df)}")

# ============================================================
# STRATIFIED SAMPLING
# ============================================================

selected = []

for esi in [1, 2, 3, 4, 5]:

    group = df[df["esi_level"] == esi]

    # her sınıftan 20 örnek
    sample = group.sample(
        n=20,
        random_state=42
    )

    selected.append(sample)

# ============================================================
# MERGE
# ============================================================

final_df = pd.concat(selected)

# ============================================================
# SHUFFLE
# ============================================================

final_df = final_df.sample(
    frac=1,
    random_state=42
).reset_index(drop=True)

# ============================================================
# SAVE
# ============================================================

final_df.to_csv(
    "selected_cases_100.csv",
    index=False
)

print("\nTotal selected:")
print(len(final_df))

print("\nESI distribution:")
print(
    final_df["esi_level"]
    .value_counts()
    .sort_index()
)

print("\nFirst 10 cases:")

print(
    final_df[
        [
            "encounter_id",
            "age",
            "chief_complaint",
            "esi_level"
        ]
    ].head(10)
)

print("\nselected_cases_100.csv created!")