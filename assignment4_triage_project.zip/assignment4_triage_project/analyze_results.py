import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# LOAD RESULTS
# ============================================================

single_df = pd.read_csv("single_agent_results.csv")
multi_df = pd.read_csv("multi_agent_results.csv")

print("=" * 60)
print("ASSIGNMENT 4 - RESULT ANALYSIS")
print("=" * 60)

# ============================================================
# BASIC METRICS
# ============================================================

single_avg_latency = single_df["latency"].mean()
multi_avg_latency = multi_df["latency"].mean()

single_avg_tokens = single_df["tokens"].mean()
multi_avg_tokens = multi_df["tokens"].mean()

print("\nAVERAGE LATENCY")
print("------------------------")
print(f"Single-Agent: {single_avg_latency:.2f} sec")
print(f"Multi-Agent: {multi_avg_latency:.2f} sec")

print("\nAVERAGE TOKEN USAGE")
print("------------------------")
print(f"Single-Agent: {single_avg_tokens:.2f}")
print(f"Multi-Agent: {multi_avg_tokens:.2f}")

# ============================================================
# CREATE COMPARISON TABLE
# ============================================================

comparison_df = pd.DataFrame({

    "Metric": [
        "Average Latency",
        "Average Token Usage"
    ],

    "Single-Agent": [
        round(single_avg_latency, 2),
        round(single_avg_tokens, 2)
    ],

    "Multi-Agent": [
        round(multi_avg_latency, 2),
        round(multi_avg_tokens, 2)
    ]
})

comparison_df.to_csv("comparison_metrics.csv", index=False)

print("\ncomparison_metrics.csv created!")

# ============================================================
# LATENCY GRAPH
# ============================================================

plt.figure(figsize=(6, 5))

systems = ["Single-Agent", "Multi-Agent"]
latencies = [single_avg_latency, multi_avg_latency]

plt.bar(systems, latencies)

plt.ylabel("Seconds")
plt.title("Average Latency Comparison")

plt.savefig("latency_comparison.png")

print("latency_comparison.png created!")

# ============================================================
# TOKEN GRAPH
# ============================================================

plt.figure(figsize=(6, 5))

tokens = [single_avg_tokens, multi_avg_tokens]

plt.bar(systems, tokens)

plt.ylabel("Approx Tokens")
plt.title("Average Token Usage Comparison")

plt.savefig("token_comparison.png")

print("token_comparison.png created!")

print("\nAnalysis completed!")