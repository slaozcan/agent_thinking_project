import pandas as pd

df = pd.read_csv("multi_agent_20_results.csv")

print(df["predicted_esi"].value_counts(dropna=False))