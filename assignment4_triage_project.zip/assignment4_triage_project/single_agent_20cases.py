import os
import re
import pandas as pd
from groq import Groq

# ============================================================
# GROQ SETUP
# ============================================================

client = Groq(
    api_key=os.environ.get("GROQ_API_KEY")
)

# ============================================================
# LOAD DATA
# ============================================================

df = pd.read_csv("selected_cases_100.csv")

# ilk 20 case
test_cases = df.head(20)

results = []

print("=" * 60)
print("SINGLE AGENT - 20 CASE EVALUATION")
print("=" * 60)

# ============================================================
# LOOP
# ============================================================

for idx, case in test_cases.iterrows():

    print(f"\nCase {idx + 1}/20")

    prompt = f"""
You are an Emergency Department triage physician.

Determine the Emergency Severity Index.

Return ONLY:

ESI: [1-5]

Patient:

Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
Troponin: {case['troponin']}
Lactate: {case['lactate']}
"""

    try:

        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0
        )

        response_text = response.choices[0].message.content

    except Exception as e:

        print("ERROR:", e)

        response_text = ""

    # ========================================================
    # PARSE ESI
    # ========================================================

    match = re.search(
        r"ESI:\s*([1-5])",
        response_text
    )

    if match:
        predicted_esi = int(match.group(1))
    else:
        predicted_esi = None

    print(
        f"Expected={case['esi_level']} "
        f"Predicted={predicted_esi}"
    )

    results.append({

        "encounter_id":
            case["encounter_id"],

        "expected_esi":
            case["esi_level"],

        "predicted_esi":
            predicted_esi
    })

# ============================================================
# SAVE
# ============================================================

results_df = pd.DataFrame(results)

results_df.to_csv(
    "single_agent_20_results.csv",
    index=False
)

print("\n")
print("=" * 60)
print("COMPLETED")
print("=" * 60)
print("Saved:")
print("single_agent_20_results.csv")
