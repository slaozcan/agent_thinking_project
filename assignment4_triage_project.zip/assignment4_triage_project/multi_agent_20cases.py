import os
import re
import time
import pandas as pd

from groq import Groq

# ============================================================
# GROQ SETUP
# ============================================================

client = Groq(
    api_key=os.environ.get("GROQ_API_KEY")
)

# ============================================================
# GROQ CALL FUNCTION
# ============================================================

def call_groq(prompt):

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0
    )

    return response.choices[0].message.content

# ============================================================
# LOAD SELECTED 100 CASES
# ============================================================

print("=" * 60)
print("MULTI AGENT - 20 CASE EVALUATION")
print("=" * 60)

selected_df = pd.read_csv("selected_cases_100.csv")

print("\nSelected cases loaded!")
print(f"Total selected cases: {len(selected_df)}")

# ============================================================
# MULTI AGENT SYSTEM
# ============================================================

def evaluate_multi_agent(case):

    base_case = f"""
PATIENT INFORMATION:

Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
- Systolic BP: {case['systolic_bp']}
- Diastolic BP: {case['diastolic_bp']}
- Heart Rate: {case['heart_rate']}
- Respiratory Rate: {case['respiratory_rate']}
- Temperature: {case['temperature']}
- SpO2: {case['spo2']}

Lab Results:
- Troponin: {case['troponin']}
- Lactate: {case['lactate']}
"""

    cardiologist_prompt = f"""
You are a Cardiologist Triage Specialist.

Focus on cardiac risk, shock, hypoxia, troponin abnormality, and life-threatening instability.

Determine Emergency Severity Index.

Return ONLY:

ESI: [1-5]

{base_case}
"""

    trauma_prompt = f"""
You are a Trauma and Systemic Risk Triage Specialist.

Focus on physiological instability, respiratory distress, altered mental status, shock, and systemic deterioration.

Determine Emergency Severity Index.

Return ONLY:

ESI: [1-5]

{base_case}
"""

    gp_prompt = f"""
You are a General Practitioner in a busy emergency department.

Avoid unnecessary over-triage. Consider stable vitals, low-acuity complaints, and expected resource use.

Determine Emergency Severity Index.

Return ONLY:

ESI: [1-5]

{base_case}
"""

    start_time = time.time()

    print("\n[Cardiologist evaluating...]")
    cardio_response = call_groq(cardiologist_prompt)

    print("\n[Trauma Specialist evaluating...]")
    trauma_response = call_groq(trauma_prompt)

    print("\n[GP evaluating...]")
    gp_response = call_groq(gp_prompt)

    coordinator_prompt = f"""
You are the Chief Emergency Physician.

Three specialists evaluated the same patient.

Your task:
- compare their ESI opinions
- resolve disagreements
- avoid unsafe under-triage
- avoid unnecessary over-triage when the patient is clearly stable

Patient:
{base_case}

Cardiologist:
{cardio_response}

Trauma/Systemic Risk Specialist:
{trauma_response}

General Practitioner:
{gp_response}

Return ONLY:

ESI: [1-5]
"""

    print("\n[Coordinator evaluating...]")
    final_response = call_groq(coordinator_prompt)

    end_time = time.time()

    elapsed = round(end_time - start_time, 2)

    total_tokens = (
        len(cardiologist_prompt.split())
        + len(trauma_prompt.split())
        + len(gp_prompt.split())
        + len(coordinator_prompt.split())
    )

    return {
        "cardiologist": cardio_response,
        "trauma": trauma_response,
        "gp": gp_response,
        "final": final_response,
        "latency": elapsed,
        "tokens": total_tokens
    }

# ============================================================
# RUN 20 CASES
# ============================================================

results = []

test_cases = selected_df.head(20)

print("\nStarting Multi-Agent Evaluation on 20 cases...\n")

for index, row in test_cases.iterrows():

    print("\n" + "=" * 60)
    print(f"CASE {index + 1}/20")
    print("=" * 60)

    print(f"Chief Complaint: {row['chief_complaint']}")
    print(f"Expected ESI: {row['esi_level']}")

    try:
        result = evaluate_multi_agent(row)
    except Exception as e:
        print("ERROR:", e)
        result = {
            "cardiologist": "",
            "trauma": "",
            "gp": "",
            "final": "",
            "latency": None,
            "tokens": None
        }

    match = re.search(
        r"ESI:\s*([1-5])",
        result["final"]
    )

    if match:
        predicted_esi = int(match.group(1))
    else:
        predicted_esi = None

    print("\nCardiologist:", result["cardiologist"])
    print("Trauma:", result["trauma"])
    print("GP:", result["gp"])
    print("Coordinator Final:", result["final"])

    print(
        f"\nExpected={row['esi_level']} "
        f"Predicted={predicted_esi}"
    )

    results.append({
        "encounter_id": row["encounter_id"],
        "expected_esi": row["esi_level"],
        "predicted_esi": predicted_esi,
        "cardiologist_response": result["cardiologist"],
        "trauma_response": result["trauma"],
        "gp_response": result["gp"],
        "coordinator_response": result["final"],
        "latency": result["latency"],
        "tokens": result["tokens"]
    })

    pd.DataFrame(results).to_csv(
        "multi_agent_20_results.csv",
        index=False
    )

    print("Progress saved to multi_agent_20_results.csv")

# ============================================================
# FINAL SAVE
# ============================================================

pd.DataFrame(results).to_csv(
    "multi_agent_20_results.csv",
    index=False
)

print("\nMulti-Agent 20 Case Experiment Completed!")
print("Results saved: multi_agent_20_results.csv")