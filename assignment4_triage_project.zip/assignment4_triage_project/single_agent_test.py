import os
import pandas as pd
from groq import Groq

client = Groq(
    api_key=os.environ.get("")
)

df = pd.read_csv("selected_cases_100.csv")

case = df.iloc[0]

prompt = f"""
You are an Emergency Department triage physician.

Determine the Emergency Severity Index (ESI).

Return ONLY:

ESI: [1-5]

Patient:

Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
WBC: {case['wbc']}
Hemoglobin: {case['hemoglobin']}
Platelets: {case['platelet_count']}
Sodium: {case['sodium']}
Potassium: {case['potassium']}
Creatinine: {case['creatinine']}
Glucose: {case['glucose']}
Troponin: {case['troponin']}
BNP: {case['bnp']}
Lactate: {case['lactate']}
INR: {case['inr']}
"""

response = client.chat.completions.create(
    model="llama-3.1-8b-instant",
    messages=[
        {
            "role": "user",
            "content": prompt
        }
    ],
    temperature=0
)

print("=" * 60)
print("EXPECTED ESI:")
print(case["esi_level"])

print("\nMODEL RESPONSE:")
print(response.choices[0].message.content)