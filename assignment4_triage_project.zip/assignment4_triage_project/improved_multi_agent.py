import os
import time
import pandas as pd
from google import genai

API_KEY = os.getenv("AIzaSyBfJd6mfkh_TG3F6ATHADPevJf54E4oKyc")
client = genai.Client(api_key=API_KEY)

selected_df = pd.read_csv("selected_cases.csv")


def call_gemini(prompt):
    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        return response.text
    except Exception as e:
        error_text = str(e)
        print("\n[ERROR]", error_text)

        if "GenerateRequestsPerDay" in error_text or "quotaValue': '20'" in error_text:
            return "QUOTA_EXCEEDED"

        return "ERROR"


def build_case_text(case):
    return f"""
Age: {case['age']}
Sex: {case['sex']}
Chief Complaint: {case['chief_complaint']}
Clinical Notes: {case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
Troponin: {case['troponin']}
Lactate: {case['lactate']}
"""


def agent_prompt(role, instruction, case_text):
    return f"""
You are {role}.

{instruction}

Determine the Emergency Severity Index.

Return ONLY:

ESI: [1-5]
Confidence: [0-100]
Reason: [short reason]

Patient:
{case_text}
"""


def evaluate_improved_multi_agent(case):
    case_text = build_case_text(case)

    prompts = {
        "cardiologist": agent_prompt(
            "a Cardiologist Triage Specialist",
            "Focus on cardiac risk, chest pain, hypoxia, troponin, shock, and life-threatening instability.",
            case_text
        ),
        "trauma": agent_prompt(
            "a Trauma and Systemic Risk Specialist",
            "Focus on vital instability, systemic deterioration, shock, respiratory distress, and severe injury.",
            case_text
        ),
        "gp": agent_prompt(
            "a General Practitioner in a busy ED",
            "Avoid unnecessary over-triage. Consider resource use, stable vitals, and low-acuity complaints.",
            case_text
        )
    }

    start = time.time()

    print("\n[Cardiologist evaluating...]")
    cardio = call_gemini(prompts["cardiologist"])
    time.sleep(3)

    print("\n[Trauma/Systemic Risk evaluating...]")
    trauma = call_gemini(prompts["trauma"])
    time.sleep(3)

    print("\n[GP evaluating...]")
    gp = call_gemini(prompts["gp"])
    time.sleep(3)

    coordinator_prompt = f"""
You are the Chief Emergency Physician.

Three agents gave opinions. Use confidence scores and clinical safety logic.
Do not simply majority vote. Avoid both unsafe under-triage and unnecessary over-triage.

Patient:
{case_text}

Cardiologist:
{cardio}

Trauma/Systemic:
{trauma}

GP:
{gp}

Return ONLY:

FINAL ESI: [1-5]
Confidence: [0-100]
Consensus Reason: [short reason]
Human Review Required: [YES/NO]
"""

    print("\n[Coordinator evaluating...]")
    coordinator = call_gemini(coordinator_prompt)
    time.sleep(3)

    verifier_prompt = f"""
You are a Medical Safety Verifier.

Check whether the coordinator's final ESI is supported by the patient data.
Look for:
- unsafe under-triage
- excessive over-triage
- missing information
- inconsistent reasoning
- need for human review

Patient:
{case_text}

Coordinator Decision:
{coordinator}

Return ONLY:

Verification: [APPROVED / REVISE / HUMAN_REVIEW]
Verifier Reason: [short reason]
Suggested ESI: [1-5 or SAME]
"""

    print("\n[Verifier evaluating...]")
    verifier = call_gemini(verifier_prompt)

    end = time.time()

    total_tokens = (
        sum(len(p.split()) for p in prompts.values())
        + len(coordinator_prompt.split())
        + len(verifier_prompt.split())
    )

    return {
        "cardiologist": cardio,
        "trauma": trauma,
        "gp": gp,
        "coordinator": coordinator,
        "verifier": verifier,
        "latency": round(end - start, 2),
        "tokens": total_tokens
    }


results = []

# quota korumak için 1 case ile başlıyoruz
test_cases = selected_df.head(1)

print("=" * 60)
print("ASSIGNMENT 4 - IMPROVED MULTI-AGENT SYSTEM")
print("=" * 60)

for index, row in test_cases.iterrows():
    print("\n" + "=" * 60)
    print(f"CASE {index + 1}")
    print("=" * 60)
    print(f"Chief Complaint: {row['chief_complaint']}")
    print(f"Expected ESI: {row['esi_level']}")

    result = evaluate_improved_multi_agent(row)

    print("\nCARDIOLOGIST:")
    print(result["cardiologist"])

    print("\nTRAUMA:")
    print(result["trauma"])

    print("\nGP:")
    print(result["gp"])

    print("\nCOORDINATOR:")
    print(result["coordinator"])

    print("\nVERIFIER:")
    print(result["verifier"])

    print(f"\nLatency: {result['latency']} sec")
    print(f"Approx Tokens: {result['tokens']}")

    results.append({
        "encounter_id": row["encounter_id"],
        "expected_esi": row["esi_level"],
        "cardiologist": result["cardiologist"],
        "trauma": result["trauma"],
        "gp": result["gp"],
        "coordinator": result["coordinator"],
        "verifier": result["verifier"],
        "latency": result["latency"],
        "tokens": result["tokens"]
    })

    pd.DataFrame(results).to_csv("improved_multi_agent_results.csv", index=False)
    print("\nProgress saved to improved_multi_agent_results.csv")

print("\nImproved Multi-Agent Experiment Completed!")