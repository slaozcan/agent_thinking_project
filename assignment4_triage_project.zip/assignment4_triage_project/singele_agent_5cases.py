import os
import re
import pandas as pd
from groq import Groq

# ============================================================
# GROQ SETUP
# ============================================================

client = Groq(
    api_key=os.environ.get("GROQ_API_KEY")
)

# ============================================================
# LOAD DATA
# ============================================================

df = pd.read_csv("selected_cases_100.csv")

# sadece ilk 5 case
test_cases = df.head(5)

results = []

print("=" * 60)
print("SINGLE AGENT - 5 CASE TEST")
print("=" * 60)

# ============================================================
# LOOP
# ============================================================

for idx, case in test_cases.iterrows():

    print("\n" + "=" * 60)
    print(f"CASE {idx + 1}")
    print("=" * 60)

    prompt = f"""
You are an Emergency Department triage physician.

Determine the Emergency Severity Index (ESI).

Return EXACTLY:

ESI: [1-5]

Patient:

Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
WBC: {case['wbc']}
Hemoglobin: {case['hemoglobin']}
Platelets: {case['platelet_count']}
Sodium: {case['sodium']}
Potassium: {case['potassium']}
Creatinine: {case['creatinine']}
Glucose: {case['glucose']}
Troponin: {case['troponin']}
BNP: {case['bnp']}
Lactate: {case['lactate']}
INR: {case['inr']}
"""

    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0
    )

    response_text = response.choices[0].message.content

    print("EXPECTED:", case["esi_level"])
    print("RESPONSE:")
    print(response_text)

    # ========================================================
    # ESI PARSE
    # ========================================================

    match = re.search(r"ESI:\s*([1-5])", response_text)

    if match:
        predicted_esi = int(match.group(1))
    else:
        predicted_esi = None

    print("PARSED ESI:", predicted_esi)

    results.append({
        "encounter_id": case["encounter_id"],
        "expected_esi": case["esi_level"],
        "predicted_esi": predicted_esi,
        "full_response": response_text
    })

# ============================================================
# SAVE
# ============================================================

results_df = pd.DataFrame(results)

results_df.to_csv(
    "single_agent_5cases_results.csv",
    index=False
)

print("\n")
print("=" * 60)
print("TEST COMPLETED")
print("=" * 60)
print("Results saved:")
print("single_agent_5cases_results.csv")