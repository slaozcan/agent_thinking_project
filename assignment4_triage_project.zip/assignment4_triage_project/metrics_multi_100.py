import pandas as pd

df = pd.read_csv("multi_agent_majority_100_results.csv")

correct = (
    df["expected_esi"] ==
    df["predicted_esi"]
).sum()

total = len(df)

print("=" * 60)
print("MULTI AGENT MAJORITY - 100 CASE")
print("=" * 60)

print("Correct :", correct)
print("Total   :", total)
print("Accuracy:", correct / total)