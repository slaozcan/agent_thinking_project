from huggingface_hub import hf_hub_download
import shutil

path = hf_hub_download(
    repo_id="olaflaitinen/fedmml-ed-triage",
    repo_type="dataset",
    filename="fedmml_ed_triage_dataset.csv"
)

print("Dataset bulundu:")
print(path)

shutil.copy(
    path,
    r"C:\Users\SILA\OneDrive - isik.edu.tr\Masaüstü\assignment4_triage_project\fedmml_ed_triage_dataset.csv"
)

print("Dataset proje klasörüne kopyalandı.")