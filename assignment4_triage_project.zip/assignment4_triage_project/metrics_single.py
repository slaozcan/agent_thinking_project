import pandas as pd

df = pd.read_csv("single_agent_100_results.csv")

total = len(df)

correct = (df["expected_esi"] == df["predicted_esi"]).sum()

accuracy = correct / total

print("=" * 60)
print("SINGLE AGENT RESULTS")
print("=" * 60)

print(f"Total Cases : {total}")
print(f"Correct     : {correct}")
print(f"Incorrect   : {total - correct}")
print(f"Accuracy    : {accuracy:.4f}")