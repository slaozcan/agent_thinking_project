import pandas as pd

# ============================================================
# LOAD RESULTS
# ============================================================

df = pd.read_csv("improved_hybrid_100_results.csv")

# ============================================================
# ACCURACY
# ============================================================

correct = (
    df["expected_esi"] ==
    df["predicted_esi"]
).sum()

total = len(df)

accuracy = correct / total

# ============================================================
# PRECISION / RECALL / F1
# ============================================================

classes = [1, 2, 3, 4, 5]

precision_list = []
recall_list = []
f1_list = []

print("=" * 60)
print("PER-CLASS METRICS")
print("=" * 60)

for cls in classes:

    tp = len(df[
        (df["expected_esi"] == cls) &
        (df["predicted_esi"] == cls)
    ])

    fp = len(df[
        (df["expected_esi"] != cls) &
        (df["predicted_esi"] == cls)
    ])

    fn = len(df[
        (df["expected_esi"] == cls) &
        (df["predicted_esi"] != cls)
    ])

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0

    recall = tp / (tp + fn) if (tp + fn) > 0 else 0

    if precision + recall > 0:
        f1 = (
            2 * precision * recall
            / (precision + recall)
        )
    else:
        f1 = 0

    precision_list.append(precision)
    recall_list.append(recall)
    f1_list.append(f1)

    print(
        f"ESI {cls} | "
        f"Precision={precision:.3f} "
        f"Recall={recall:.3f} "
        f"F1={f1:.3f}"
    )

# ============================================================
# MACRO AVERAGES
# ============================================================

macro_precision = sum(precision_list) / 5
macro_recall = sum(recall_list) / 5
macro_f1 = sum(f1_list) / 5

print("\n" + "=" * 60)
print("OVERALL RESULTS")
print("=" * 60)

print(f"Accuracy       : {accuracy:.4f}")
print(f"Macro Precision: {macro_precision:.4f}")
print(f"Macro Recall   : {macro_recall:.4f}")
print(f"Macro F1       : {macro_f1:.4f}")