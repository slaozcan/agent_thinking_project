import os
import re
import pandas as pd
from groq import Groq

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))


def call_groq(prompt):
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0
    )
    return response.choices[0].message.content.strip()


def evaluate_multi_agent(case):
    patient_info = f"""
Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
Troponin: {case['troponin']}
Lactate: {case['lactate']}
"""

    cardiologist_prompt = f"""
You are a Cardiologist.

Focus on chest pain, cardiac arrest, troponin, hypoxia, and shock.

Return ONLY:
ESI: [1-5]

{patient_info}
"""

    trauma_prompt = f"""
You are a Trauma and Critical Care Specialist.

Focus on unstable vitals, respiratory distress, shock, and altered consciousness.

Return ONLY:
ESI: [1-5]

{patient_info}
"""

    gp_prompt = f"""
You are a General Practitioner.

Focus on avoiding over-triage, overall patient stability, and expected resource usage.

Return ONLY:
ESI: [1-5]

{patient_info}
"""

    cardio = call_groq(cardiologist_prompt)
    trauma = call_groq(trauma_prompt)
    gp = call_groq(gp_prompt)

    coordinator_prompt = f"""
You are the Chief Emergency Physician.

Specialist decisions:

Cardiologist:
{cardio}

Trauma:
{trauma}

GP:
{gp}

Choose the safest final ESI.

Return ONLY:
ESI: [1-5]
"""

    final = call_groq(coordinator_prompt)

    return {
        "cardio": cardio,
        "trauma": trauma,
        "gp": gp,
        "final": final
    }


df = pd.read_csv("selected_cases_100.csv")
test_cases = df.head(20)

results = []

print("=" * 60)
print("MULTI AGENT V2 - 20 CASES")
print("=" * 60)

for idx, row in test_cases.iterrows():
    print(f"\nCase {idx + 1}/20")

    result = evaluate_multi_agent(row)

    match = re.search(r"([1-5])", result["final"])

    if match:
        predicted = int(match.group(1))
    else:
        predicted = None

    print(f"Expected={row['esi_level']} Predicted={predicted}")

    results.append({
        "encounter_id": row["encounter_id"],
        "expected_esi": row["esi_level"],
        "predicted_esi": predicted,
        "cardio_response": result["cardio"],
        "trauma_response": result["trauma"],
        "gp_response": result["gp"],
        "final_response": result["final"]
    })

    pd.DataFrame(results).to_csv(
        "multi_agent_20_v2_results.csv",
        index=False
    )

pd.DataFrame(results).to_csv(
    "multi_agent_20_v2_results.csv",
    index=False
)

print("\nCompleted.")
print("Saved: multi_agent_20_v2_results.csv")