import os
import time
import pandas as pd

from huggingface_hub import hf_hub_download
from google import genai

# ============================================================
# API SETUP
# ============================================================

API_KEY = os.getenv("AIzaSyCUupO_sT1S94wBQcwEw_k_XCYX0v9RgKk")

client = genai.Client(api_key=API_KEY)

# ============================================================
# DATASET LOAD
# ============================================================

print("=" * 60)
print("ASSIGNMENT 4 - MULTI AGENT TRIAGE SYSTEM")
print("=" * 60)

repo_id = "olaflaitinen/fedmml-ed-triage"

file_path = hf_hub_download(
    repo_id=repo_id,
    repo_type="dataset",
    filename="fedmml_ed_triage_dataset.csv"
)

df = pd.read_csv(file_path)

print("\nDataset loaded!")
print(f"Total rows: {len(df)}")

# ============================================================
# SELECTED CASES LOAD
# ============================================================

selected_df = pd.read_csv("selected_cases.csv")

print("\nSelected test cases loaded!")
print(f"Case count: {len(selected_df)}")

# ============================================================
# GEMINI CALL FUNCTION
# ============================================================

def call_gemini(prompt):

    max_retries = 2

    for attempt in range(max_retries):

        try:

            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt
            )

            return response.text

        except Exception as e:

            error_text = str(e)

            print(f"\n[ERROR] {error_text}")

            # daily quota exceeded
            if "GenerateRequestsPerDay" in error_text or "quotaValue': '20'" in error_text:

                print("Daily quota exceeded. Stopping retries for this call.")

                return "QUOTA_EXCEEDED"

            # minute limit
            if "RESOURCE_EXHAUSTED" in error_text:

                wait_time = 60

            else:

                wait_time = 5 * (attempt + 1)

            if attempt < max_retries - 1:

                print(f"Retrying in {wait_time} seconds...")

                time.sleep(wait_time)

            else:

                return "ERROR"

# ============================================================
# MULTI AGENT SYSTEM
# ============================================================

def evaluate_multi_agent(case):

    base_case = f"""
PATIENT INFORMATION:

Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
- Systolic BP: {case['systolic_bp']}
- Diastolic BP: {case['diastolic_bp']}
- Heart Rate: {case['heart_rate']}
- Respiratory Rate: {case['respiratory_rate']}
- Temperature: {case['temperature']}
- SpO2: {case['spo2']}

Lab Results:
- Troponin: {case['troponin']}
- Lactate: {case['lactate']}
"""

    # ========================================================
    # CARDIOLOGIST
    # ========================================================

    cardiologist_prompt = f"""
You are a Cardiologist Triage Specialist.

You are highly sensitive to cardiac and life-threatening risks.

Determine Emergency Severity Index (ESI 1-5).

Return format:

ESI: [NUMBER]
Reason: [SHORT EXPLANATION]

{base_case}
"""

    # ========================================================
    # TRAUMA SPECIALIST
    # ========================================================

    trauma_prompt = f"""
You are a Trauma and Systemic Risk Triage Specialist.

Focus on physiological instability and systemic deterioration.

Determine Emergency Severity Index (ESI 1-5).

Return format:

ESI: [NUMBER]
Reason: [SHORT EXPLANATION]

{base_case}
"""

    # ========================================================
    # GP
    # ========================================================

    gp_prompt = f"""
You are a General Practitioner in a busy emergency department.

You try to avoid unnecessary escalation and over-triage.

Determine Emergency Severity Index (ESI 1-5).

Return format:

ESI: [NUMBER]
Reason: [SHORT EXPLANATION]

{base_case}
"""

    start_time = time.time()

    # ========================================================
    # AGENT CALLS
    # ========================================================

    print("\n[Cardiologist evaluating...]")
    cardio_response = call_gemini(cardiologist_prompt)

    time.sleep(3)

    print("\n[Trauma Specialist evaluating...]")
    trauma_response = call_gemini(trauma_prompt)

    time.sleep(3)

    print("\n[GP evaluating...]")
    gp_response = call_gemini(gp_prompt)

    # ========================================================
    # COORDINATOR
    # ========================================================

    coordinator_prompt = f"""
You are the Chief Emergency Physician.

Three specialists evaluated the same patient.

Your task:
- compare their opinions
- resolve disagreements
- provide the SAFEST final ESI decision

PATIENT:
{base_case}

CARDIOLOGIST:
{cardio_response}

TRAUMA SPECIALIST:
{trauma_response}

GP:
{gp_response}

Return format:

FINAL ESI: [NUMBER]
Consensus Reason: [SHORT EXPLANATION]
"""

    time.sleep(3)

    print("\n[Coordinator evaluating...]")

    final_response = call_gemini(coordinator_prompt)

    end_time = time.time()

    elapsed = round(end_time - start_time, 2)

    total_tokens = (
        len(cardiologist_prompt.split())
        + len(trauma_prompt.split())
        + len(gp_prompt.split())
        + len(coordinator_prompt.split())
    )

    return {
        "cardiologist": cardio_response,
        "trauma": trauma_response,
        "gp": gp_response,
        "final": final_response,
        "latency": elapsed,
        "tokens": total_tokens
    }

# ============================================================
# RUN MULTI AGENT EXPERIMENT
# ============================================================

results = []

# sadece ilk 2 case
# quota bitmesin diye
test_cases = selected_df.head(2)

print("\nStarting Multi-Agent Evaluation...\n")

for index, row in test_cases.iterrows():

    print("\n" + "=" * 60)
    print(f"CASE {index + 1}")
    print("=" * 60)

    print(f"Chief Complaint: {row['chief_complaint']}")
    print(f"Expected ESI: {row['esi_level']}")

    result = evaluate_multi_agent(row)

    # ========================================================
    # PRINT RESULTS
    # ========================================================

    print("\n-----------------------------")
    print("CARDIOLOGIST")
    print("-----------------------------")
    print(result["cardiologist"])

    print("\n-----------------------------")
    print("TRAUMA SPECIALIST")
    print("-----------------------------")
    print(result["trauma"])

    print("\n-----------------------------")
    print("GP")
    print("-----------------------------")
    print(result["gp"])

    print("\n-----------------------------")
    print("COORDINATOR FINAL DECISION")
    print("-----------------------------")
    print(result["final"])

    print(f"\nLatency: {result['latency']} sec")
    print(f"Approx Tokens: {result['tokens']}")

    # ========================================================
    # SAVE RESULT
    # ========================================================

    results.append({

        "encounter_id": row["encounter_id"],
        "expected_esi": row["esi_level"],
        "cardiologist": result["cardiologist"],
        "trauma": result["trauma"],
        "gp": result["gp"],
        "final_decision": result["final"],
        "latency": result["latency"],
        "tokens": result["tokens"]
    })

    # her case sonrası save
    pd.DataFrame(results).to_csv(
        "multi_agent_results.csv",
        index=False
    )

    print("\nProgress saved to multi_agent_results.csv")

# ============================================================
# FINAL SAVE
# ============================================================

results_df = pd.DataFrame(results)

results_df.to_csv("multi_agent_results.csv", index=False)

print("\nMulti-Agent Experiment Completed!")

print("\nResults saved:")
print("multi_agent_results.csv")