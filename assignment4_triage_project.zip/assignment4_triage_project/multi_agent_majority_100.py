import os
import re
import pandas as pd
from collections import Counter
from groq import Groq

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))


def call_groq(prompt):
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {
                "role": "user",
                "content": prompt
            }
        ],
        temperature=0
    )
    return response.choices[0].message.content.strip()


def extract_esi(text):
    match = re.search(r"([1-5])", str(text))
    if match:
        return int(match.group(1))
    return None


def majority_vote(votes):
    clean_votes = [v for v in votes if v is not None]

    if len(clean_votes) == 0:
        return None

    counter = Counter(clean_votes)

    # En çok oy alanı seç
    most_common = counter.most_common()

    # Eğer tek kazanan varsa onu döndür
    if len(most_common) == 1:
        return most_common[0][0]

    if most_common[0][1] > most_common[1][1]:
        return most_common[0][0]

    # Beraberlik varsa daha acil olanı seç: küçük ESI daha acildir
    tied_vote_count = most_common[0][1]
    tied_values = [
        esi for esi, count in most_common
        if count == tied_vote_count
    ]

    return min(tied_values)


def evaluate_multi_agent(case):
    patient_info = f"""
Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
Troponin: {case['troponin']}
Lactate: {case['lactate']}
"""

    cardiologist_prompt = f"""
You are a Cardiologist.

Focus on chest pain, cardiac arrest, troponin, hypoxia, and shock.

Return ONLY:
ESI: [1-5]

{patient_info}
"""

    trauma_prompt = f"""
You are a Trauma and Critical Care Specialist.

Focus on unstable vitals, respiratory distress, shock, and altered consciousness.

Return ONLY:
ESI: [1-5]

{patient_info}
"""

    gp_prompt = f"""
You are a General Practitioner.

Focus on avoiding over-triage, overall patient stability, and expected resource usage.

Return ONLY:
ESI: [1-5]

{patient_info}
"""

    cardio_response = call_groq(cardiologist_prompt)
    trauma_response = call_groq(trauma_prompt)
    gp_response = call_groq(gp_prompt)

    cardio_esi = extract_esi(cardio_response)
    trauma_esi = extract_esi(trauma_response)
    gp_esi = extract_esi(gp_response)

    final_prediction = majority_vote([
        cardio_esi,
        trauma_esi,
        gp_esi
    ])

    return {
        "cardio": cardio_esi,
        "trauma": trauma_esi,
        "gp": gp_esi,
        "final": final_prediction,
        "cardio_response": cardio_response,
        "trauma_response": trauma_response,
        "gp_response": gp_response
    }


df = pd.read_csv("selected_cases_100.csv")
test_cases = df.head(100)

results = []

print("=" * 60)
print("MULTI AGENT MAJORITY - 100 CASES")
print("=" * 60)

for idx, row in test_cases.iterrows():
    print(f"\nCase {idx + 1}/100")

    result = evaluate_multi_agent(row)

    predicted = result["final"]

    print(
        f"Expected={row['esi_level']} "
        f"Cardio={result['cardio']} "
        f"Trauma={result['trauma']} "
        f"GP={result['gp']} "
        f"Final={predicted}"
    )

    results.append({
        "encounter_id": row["encounter_id"],
        "expected_esi": row["esi_level"],
        "predicted_esi": predicted,
        "cardio_esi": result["cardio"],
        "trauma_esi": result["trauma"],
        "gp_esi": result["gp"],
        "cardio_response": result["cardio_response"],
        "trauma_response": result["trauma_response"],
        "gp_response": result["gp_response"]
    })

    pd.DataFrame(results).to_csv(
        "multi_agent_majority_100_results.csv",
        index=False
    )

pd.DataFrame(results).to_csv(
    "multi_agent_majority_100_results.csv",
    index=False
)

print("\nCompleted.")
print("Saved: multi_agent_majority_100_results.csv")