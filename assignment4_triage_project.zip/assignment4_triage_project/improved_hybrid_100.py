import os
import re
import pandas as pd
from collections import Counter
from groq import Groq

client = Groq(api_key=os.environ.get("GROQ_API_KEY"))


def call_groq(prompt):
    response = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content.strip()


def extract_esi(text):
    match = re.search(r"([1-5])", str(text))
    if match:
        return int(match.group(1))
    return None


def build_patient_info(case):
    return f"""
Age: {case['age']}
Sex: {case['sex']}

Chief Complaint:
{case['chief_complaint']}

Clinical Notes:
{case['clinical_notes']}

Vitals:
SBP: {case['systolic_bp']}
DBP: {case['diastolic_bp']}
HR: {case['heart_rate']}
RR: {case['respiratory_rate']}
Temp: {case['temperature']}
SpO2: {case['spo2']}

Labs:
Pain Score: {case['pain_score']}
WBC: {case['wbc']}
Hemoglobin: {case['hemoglobin']}
Platelets: {case['platelet_count']}
Sodium: {case['sodium']}
Potassium: {case['potassium']}
Creatinine: {case['creatinine']}
Glucose: {case['glucose']}
Troponin: {case['troponin']}
BNP: {case['bnp']}
Lactate: {case['lactate']}
INR: {case['inr']}
"""


def ask_single_agent(case):
    patient_info = build_patient_info(case)

    prompt = f"""
You are an Emergency Department triage physician.

Determine the Emergency Severity Index.

Return ONLY:
ESI: [1-5]

Patient:
{patient_info}
"""

    response = call_groq(prompt)
    return extract_esi(response), response


def ask_specialist(case, role, focus):
    patient_info = build_patient_info(case)

    prompt = f"""
You are {role}.

Focus on:
{focus}

Determine the Emergency Severity Index.

Return ONLY:
ESI: [1-5]

Patient:
{patient_info}
"""

    response = call_groq(prompt)
    return extract_esi(response), response


def has_critical_keywords(case):
    text = (
        str(case["chief_complaint"]) + " " +
        str(case["clinical_notes"])
    ).lower()

    critical_words = [
        "cardiac arrest",
        "unresponsive",
        "massive hemorrhage",
        "severe respiratory distress",
        "severe shortness of breath",
        "seizure ongoing",
        "head injury with loc",
        "altered mental status",
        "confusion",
        "shock"
    ]

    return any(word in text for word in critical_words)


def clinical_safety_override(case, single_esi, cardio_esi, trauma_esi, gp_esi):
    final_esi = single_esi
    human_review = False
    reason = "Single-agent decision kept."

    sbp = case["systolic_bp"]
    hr = case["heart_rate"]
    rr = case["respiratory_rate"]
    spo2 = case["spo2"]
    temp = case["temperature"]
    troponin = case["troponin"]
    lactate = case["lactate"]

    specialist_votes = [
        cardio_esi,
        trauma_esi,
        gp_esi
    ]

    valid_votes = [
        v for v in specialist_votes
        if v is not None
    ]

    # Human review if specialists strongly disagree
    if len(valid_votes) >= 2:
        if max(valid_votes) - min(valid_votes) >= 3:
            human_review = True

    # Rule 1: obvious life-threatening keywords
    if has_critical_keywords(case):
        if final_esi is None or final_esi > 2:
            final_esi = 2
            reason = "Critical complaint or notes detected; upgraded for safety."

    # Rule 2: severe vital instability
    if (
        spo2 < 90 or
        sbp < 90 or
        rr < 10 or
        rr > 30 or
        hr > 130
    ):
        if final_esi is None or final_esi > 2:
            final_esi = 2
            reason = "Severe vital sign instability detected; upgraded for safety."

    # Rule 3: extreme instability should be ESI 1
    if (
        spo2 < 88 or
        sbp < 80 or
        rr < 8
    ):
        if final_esi is None or final_esi > 1:
            final_esi = 1
            reason = "Extreme instability detected; upgraded to ESI 1."

    # Rule 4: cardiac risk
    if troponin == troponin and troponin > 0.5:
        if final_esi is None or final_esi > 2:
            final_esi = 2
            reason = "High troponin detected; upgraded due to cardiac risk."

    # Rule 5: lactate/sepsis risk
    if lactate == lactate and lactate >= 3:
        if final_esi is None or final_esi > 2:
            final_esi = 2
            reason = "High lactate detected; upgraded due to shock/sepsis risk."

    # Rule 6: two specialists see high acuity, but single is low acuity
    high_acuity_votes = [
        v for v in valid_votes
        if v in [1, 2]
    ]

    if len(high_acuity_votes) >= 2 and single_esi is not None and single_esi >= 4:
        final_esi = 2
        human_review = True
        reason = "Two specialists indicated high acuity; upgraded and flagged for human review."

    # Rule 7: reduce unsafe over-correction
    # If single says ESI 1 but no critical keyword/vital abnormality exists,
    # allow downgrade only when all specialists agree lower acuity.
    if single_esi == 1:
        all_specialists_lower = (
            len(valid_votes) == 3 and
            all(v >= 3 for v in valid_votes)
        )

        no_extreme_instability = not (
            has_critical_keywords(case) or
            spo2 < 88 or
            sbp < 80 or
            rr < 8
        )

        if all_specialists_lower and no_extreme_instability:
            final_esi = 3
            human_review = True
            reason = "Potential over-triage detected; downgraded with human review flag."

    if final_esi is None:
        final_esi = single_esi

    return final_esi, human_review, reason


def evaluate_improved(case):
    single_esi, single_response = ask_single_agent(case)

    cardio_esi, cardio_response = ask_specialist(
        case,
        "a Cardiologist Triage Specialist",
        "- chest pain\n- cardiac arrest\n- troponin\n- hypoxia\n- shock"
    )

    trauma_esi, trauma_response = ask_specialist(
        case,
        "a Trauma and Critical Care Specialist",
        "- unstable vitals\n- respiratory distress\n- altered consciousness\n- shock"
    )

    gp_esi, gp_response = ask_specialist(
        case,
        "a General Practitioner in a busy emergency department",
        "- avoiding unnecessary over-triage\n- stability\n- expected resource use"
    )

    final_esi, human_review, verifier_reason = clinical_safety_override(
        case,
        single_esi,
        cardio_esi,
        trauma_esi,
        gp_esi
    )

    return {
        "single_esi": single_esi,
        "cardio_esi": cardio_esi,
        "trauma_esi": trauma_esi,
        "gp_esi": gp_esi,
        "final_esi": final_esi,
        "human_review": human_review,
        "verifier_reason": verifier_reason,
        "single_response": single_response,
        "cardio_response": cardio_response,
        "trauma_response": trauma_response,
        "gp_response": gp_response
    }


df = pd.read_csv("selected_cases_100.csv")

results = []

print("=" * 60)
print("IMPROVED HYBRID MULTI-AGENT SYSTEM - 100 CASES")
print("=" * 60)

for idx, row in df.iterrows():
    print(f"\nCase {idx + 1}/100")

    try:
        result = evaluate_improved(row)
    except Exception as e:
        print("ERROR:", e)
        result = {
            "single_esi": None,
            "cardio_esi": None,
            "trauma_esi": None,
            "gp_esi": None,
            "final_esi": None,
            "human_review": True,
            "verifier_reason": "API or execution error.",
            "single_response": "",
            "cardio_response": "",
            "trauma_response": "",
            "gp_response": ""
        }

    print(
        f"Expected={row['esi_level']} "
        f"Single={result['single_esi']} "
        f"Cardio={result['cardio_esi']} "
        f"Trauma={result['trauma_esi']} "
        f"GP={result['gp_esi']} "
        f"Final={result['final_esi']} "
        f"HumanReview={result['human_review']}"
    )

    results.append({
        "encounter_id": row["encounter_id"],
        "expected_esi": row["esi_level"],
        "single_esi": result["single_esi"],
        "cardio_esi": result["cardio_esi"],
        "trauma_esi": result["trauma_esi"],
        "gp_esi": result["gp_esi"],
        "predicted_esi": result["final_esi"],
        "human_review": result["human_review"],
        "verifier_reason": result["verifier_reason"]
    })

    pd.DataFrame(results).to_csv(
        "improved_hybrid_100_results.csv",
        index=False
    )

pd.DataFrame(results).to_csv(
    "improved_hybrid_100_results.csv",
    index=False
)

print("\nCompleted.")
print("Saved: improved_hybrid_100_results.csv")